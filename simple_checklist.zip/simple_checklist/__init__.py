bl_info = {
    "name": "Checklist",
    "description": "A customizable sidebar checklist.",
    "author": "Charlie O'Shea",
    "version": (1, 0),
    "blender": (2, 80, 0),
    "location": "View3D > Sidebar > Checklist",
    "warning": "",
    "category": "UI",
}

import bpy
import json
import os
from bpy.props import StringProperty, BoolProperty, CollectionProperty, IntProperty
from bpy_extras.io_utils import ImportHelper, ExportHelper

# CHECKLIST FUNCTIONALITY

class ChecklistItem(bpy.types.PropertyGroup):
    name: StringProperty(
        name="Item Name",
        default=""
    ) # type: ignore
    completed: BoolProperty(
        name="Completed",
        default=False
    ) # type: ignore

class ChecklistProperties(bpy.types.PropertyGroup):
    checklist_items: CollectionProperty(
        name="Checklist Items",
        type=ChecklistItem
    ) # type: ignore
    def remove(self, index: int):
        self.checklist_items.remove(index)
    def clear(self):
        self.checklist_items.clear()

def clear_checklist(scene):
    # Clear all items from the checklist
    scene.checklist.checklist_items.clear()

# UI PANEL

class ChecklistPanel(bpy.types.Panel):
    bl_label = "Checklist"
    bl_idname = "VIEW3D_PT_checklist"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Checklist"

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        checklist_props = scene.checklist

        for index, item in enumerate(checklist_props.checklist_items):
            row = layout.row() # Create row for each item

            # Create text box and bool box
            row.prop(item, "name", text="", icon='LAYER_ACTIVE')
            row.prop(item, "completed", text="")

            # Remove item button
            op = row.operator("checklist.remove_item", icon='CANCEL', text = "")
            op.index = index
            
        row = layout.row()
        row.operator("checklist.add_item", text="Add Item", icon='PLUS')

        # Save and load directories
        row = layout.row()
        row.operator("checklist.load", text="Load", icon='FILE_FOLDER')
        row.operator("checklist.save", text="Save", icon='FILE_TICK')

        
       
# ADD AND REMOVE BUTTONS

class AddChecklistItem(bpy.types.Operator):
    bl_idname = "checklist.add_item"
    bl_label = "Add Item"
    bl_description = "Adds a new item to the checklist"
    bl_options = {'INTERNAL'}

    def execute(self, context):
        scene = context.scene
        checklist_props = scene.checklist
        item = checklist_props.checklist_items.add()
        item.name = "New Item"
        return {'FINISHED'}

class RemoveChecklistItem(bpy.types.Operator):
    bl_idname = "checklist.remove_item"
    bl_label = "Remove Item"
    bl_description = "Removes current item from checklist"
    bl_options = {'INTERNAL'}
    
    index: bpy.props.IntProperty() # type: ignore

    def execute(self, context):

        props = context.scene.checklist

        index = self.index
        item = props.checklist_items[index]

        props.remove(self.index)

        return {'FINISHED'}

# SAVING AND LOADING

def save_checklist(self, context):
    checklist_props = context.scene.checklist
    checklist_data = {
        "name": "",
        "items": [
            {"name": item.name, "completed": item.completed}
            for item in checklist_props.checklist_items
        ]
    }

    # Get filepath
    filepath = self.filepath

    # Extract the file name without extension
    file_name = os.path.splitext(os.path.basename(filepath))[0]
    checklist_data["name"] = file_name

    # Save checklist data to json file
    with open(filepath, "w", encoding="utf-8") as file:
        json.dump(checklist_data, file, indent=4)
    
    print(f"Checklist '{file_name}' saved to {filepath}")

def load_checklist(self, context):
    checklist_props = context.scene.checklist

    # Get filepath
    filepath = self.filepath

    # Load checklist data from json
    try:
        with open(filepath, "r", encoding="utf-8") as file:
            checklist_data = json.load(file)
    except FileNotFoundError:
        print(f"Checklist file not found: {filepath}")
        return

    # Clear existing checklist
    checklist_props.checklist_items.clear()

    # Check if the loaded data has an "items" key
    if "items" in checklist_data:
        items_data = checklist_data["items"]
    else:
        # Assume the loaded data is a list of dictionaries
        items_data = checklist_data

    # Add loaded checklist items
    for item_data in items_data:
        item = checklist_props.checklist_items.add()
        item.name = item_data["name"]
        item.completed = False

    print(f"Checklist '{checklist_data['name']}' loaded from {filepath}")

    # Force UI redraw
    context.area.tag_redraw()

class SaveChecklistOperator(bpy.types.Operator, ExportHelper):
    bl_idname = "checklist.save"
    bl_label = "Save Checklist"

    filename_ext = ".json"
    filter_glob: StringProperty(
        default="*.json",
        options={'HIDDEN'},
    ) # type: ignore

    def execute(self, context):
        save_checklist(self, context)
        return{'FINISHED'}

class LoadChecklistOperator(bpy.types.Operator, ImportHelper):
    bl_idname = "checklist.load"
    bl_label = "Load Checklist"

    filename_ext = ".json"
    filter_glob: StringProperty(
        default="*.json",
        options={'HIDDEN'}
    ) # type: ignore

    def execute(self, context):
        load_checklist(self, context)
        return{'FINISHED'}

# HELP SUB PANEL

class HelpSubPanel(bpy.types.Panel):
    bl_label = "Help"
    bl_idname = "VIEW3D_PT_checklist_help"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Checklist"
    bl_parent_id = "VIEW3D_PT_checklist"

    def draw(self, context):
        layout = self.layout
        layout.label(text="How to use:", icon='TEXT')
        layout.label(text="Use the 'Add Item' button to create a new task.", icon='DOT')
        layout.label(text="Check off completed items by toggling the checkbox.", icon='DOT')
        layout.label(text="Remove items by clicking the 'x' button next to them.", icon='DOT')
        layout.label(text="Save your checklist using the 'Save' button.", icon='DOT')
        layout.label(text="Load a saved checklist using the 'Load' button.", icon='DOT')
        layout.label(text="Some template lists can be found in the addons 'templates' folder.", icon='DOT')
        layout.label(text="Enjoy!", icon='DOT')
        
        # Credits
        row = layout.row()
        row.label(text="made by charlie :)", icon='MONKEY')
        
        

classes = (
    ChecklistItem,
    ChecklistProperties,
    AddChecklistItem,
    RemoveChecklistItem,
    SaveChecklistOperator,
    LoadChecklistOperator,
    ChecklistPanel,
    HelpSubPanel,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    bpy.types.Scene.checklist = bpy.props.PointerProperty(type=ChecklistProperties)
    #clear_checklist(bpy.context.scene)

def unregister():
    del bpy.types.Scene.checklist
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    register()