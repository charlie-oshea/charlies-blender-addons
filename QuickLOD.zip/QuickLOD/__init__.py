bl_info = {
    "name": "QuickLOD",
    "author": "charlie",
    "version": (1,0),
    "blender": (2,80,0),
    "location": "View3D > Sidebar > QuickLOD",
    "description": "Automatically generate LOD levels for selected mesh",
    "warning": "",
    "doc_url": "",
    "category": "Object",
}

import bpy
import os
from bpy.props import IntProperty, PointerProperty, FloatProperty
from bpy.types import Operator, Panel
import math

classes = []

bpy.types.Scene.target_obj = bpy.props.PointerProperty(
    name="Target Object",
    type=bpy.types.Object,
    description="Object to generate LODs for",
    poll=lambda self, obj: obj.type == 'MESH'
)
bpy.types.Scene.lod_levels = bpy.props.IntProperty(
        name="LOD Levels",
        description="Number of LOD levels to generate",
        default=3,
        min=1,
        max=10
    )
bpy.types.Scene.lod_reduction_factor = FloatProperty(
    name="Reduction Factor",
    description="Controls how quickly the mesh is simplified (higher values = more aggressive reduction)",
    default=2.0,
    min=1.0,
    max=5.0
)

class LOD_OT_Generate(Operator):
    bl_idname = "object.generate_lod"
    bl_description = "Generate specified number of LOD levels for target mesh"
    bl_label = "Generate LODs"
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(cls, context):
        return context.scene.target_obj is not None

    def execute(self, context):
        scene = context.scene
        num_levels = scene.lod_levels
        target_obj = scene.target_obj
        reduction_factor = scene.lod_reduction_factor

        if target_obj and target_obj.type == 'MESH':
            # create collection
            collection_name = f"{target_obj.name}_LODs"
            lod_collection = bpy.data.collections.new(collection_name)
            scene.collection.children.link(lod_collection)

            # create an empty parent node for the lods
            empty = bpy.data.objects.new(f"{target_obj.name}_Root", None)
            lod_collection.objects.link(empty)

            # create LOD versions

            for i in range(num_levels):
                # create new object as copy of target
                lod_obj = target_obj.copy()
                lod_obj.data = target_obj.data.copy()
                lod_obj.name = f"{target_obj.name}_LOD{i}"

                # link new object to collection
                lod_collection.objects.link(lod_obj)

                # parent the lod object to empty
                lod_obj.parent = empty

                # add decimate modifer
                decimate = lod_obj.modifiers.new(name="Decimate", type='DECIMATE')

                # exponential ratio
                ratio = math.exp(-reduction_factor * i / (num_levels - 1))
                decimate.ratio = max(0.01, ratio) # ensure ratio doesn't go below 0.01


            self.report({'INFO'}, f"Generated {num_levels} LOD levels for {scene.target_obj.name}")
        else:
            self.report({'ERROR'}, "Invalid target object")

        return {'FINISHED'}

classes.append(LOD_OT_Generate)

class LOD_PT_Panel(Panel):
    bl_label = "QuickLOD"
    bl_idname = "LOD_PT_Panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'QuickLOD'

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        # object picker
        layout.prop_search(scene, "target_obj", scene, "objects", text="Target", icon='OUTLINER_OB_MESH')

        # slider for lod levels
        layout.prop(scene, "lod_levels", slider=True)

        # slider for reduction factor
        layout.prop(scene, "lod_reduction_factor", slider=True)
        
        row = layout.row(align=True)
        row.operator("object.generate_lod", text="Generate LODs", icon='MOD_DECIM')
        

classes.append(LOD_PT_Panel)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    
def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    
    # clean up custom properties
    del bpy.types.Scene.target_obj
    del bpy.types.Scene.lod_levels
    
    

if __name__ == "__main__":
    register()