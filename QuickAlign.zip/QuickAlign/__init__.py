import bpy
from bpy.types import Operator, Panel
from bpy.props import EnumProperty
import mathutils

bl_info = {
    "name": "QuickAlign",
    "author": "charlie",
    "version": (1, 0),
    "blender": (2, 80, 0),
    "location": "View3D > Sidebar > QuickAlign",
    "description": "Align and distribute objects along a specified axis",
    "category": "Object",
}

classes = []

class AlignDistributeProperties(bpy.types.PropertyGroup):
    align_axis: EnumProperty(
        items=[
            ('X', "X", "Align on X axis"),
            ('Y', "Y", "Align on Y axis"),
            ('Z', "Z", "Align on Z axis"),
        ],
        name="Align Axis",
        default='X'
    )
    distribute_axis: EnumProperty(
        items=[
            ('X', "X", "Distribute on X axis"),
            ('Y', "Y", "Distribute on Y axis"),
            ('Z', "Z", "Distribute on Z axis"),
        ],
        name="Distribute Axis",
        default='X'
    )

classes.append(AlignDistributeProperties)

class OBJECT_OT_align_objects(Operator):
    bl_idname = "object.align_objects"
    bl_label = "Align Objects"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and len(context.selected_objects) > 1

    def execute(self, context):
        active_obj = context.active_object
        selected_objs = context.selected_objects
        align_props = context.scene.align_distribute_props

        if active_obj not in selected_objs:
            self.report({'ERROR'}, "Active object must be selected")
            return {'CANCELLED'}

        axis_index = ['X', 'Y', 'Z'].index(align_props.align_axis)
        target = active_obj.location[axis_index]

        for obj in selected_objs:
            if obj != active_obj:
                obj.location[axis_index] = target

        return {'FINISHED'}

classes.append(OBJECT_OT_align_objects)

class OBJECT_OT_distribute_objects(Operator):
    bl_idname = "object.distribute_objects"
    bl_label = "Distribute Objects"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and len(context.selected_objects) > 2

    def execute(self, context):
        selected_objs = context.selected_objects
        distribute_props = context.scene.align_distribute_props

        axis_index = ['X', 'Y', 'Z'].index(distribute_props.distribute_axis)

        # Sort objects based on their position on the chosen axis
        sorted_objs = sorted(selected_objs, key=lambda obj: obj.location[axis_index])

        start = sorted_objs[0].location[axis_index]
        end = sorted_objs[-1].location[axis_index]
        total_distance = end - start

        for i, obj in enumerate(sorted_objs[1:-1], 1):
            ratio = i / (len(sorted_objs) - 1)
            obj.location[axis_index] = start + total_distance * ratio

        return {'FINISHED'}

classes.append(OBJECT_OT_distribute_objects)

class VIEW3D_PT_align_distribute(Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "QuickAlign"
    bl_label = "Align and Distribute"

    def draw(self, context):
        layout = self.layout
        align_props = context.scene.align_distribute_props

        layout.label(text="Align Axis", icon='EMPTY_AXIS')
        layout.prop(align_props, "align_axis", expand=True)
        layout.operator(OBJECT_OT_align_objects.bl_idname, text="Align Selected", icon='MOD_MULTIRES')

        layout.separator()

        layout.label(text="Distribute Axis", icon='EMPTY_AXIS')
        layout.prop(align_props, "distribute_axis", expand=True)
        layout.operator(OBJECT_OT_distribute_objects.bl_idname, text="Distribute Selected", icon='CENTER_ONLY')

classes.append(VIEW3D_PT_align_distribute)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.align_distribute_props = bpy.props.PointerProperty(type=AlignDistributeProperties)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.align_distribute_props

if __name__ == "__main__":
    register()